<?php

$con = mysqli_connect("localhost","root","","social_network") or die("Connection was not established");

if(isset($_GET['post_id'])) {

	$post_id=$_GET['post_id'];
	$delete_post="delete from posts where post_id='$post_id'";
	$run = mysqli_query($con,$delete_post);
	
	if($run){
				echo "<script>alert('Your Post deleted a moment ago!')</script>";
			}
				else{

						echo "<script>alert('Your Post already deleted!')</script>";
					}
	
				
}  
?>

