<?php 
$con = mysqli_connect("localhost","root","","social_network") or die("Connection was not established");

$get_id=$_GET['post_id'];

$get_com="select * from comments where post_id='$get_id'ORDER by 1 DESC";
$run_com = mysqli_query($con, $get_com);
	while($row = mysqli_fetch_array($run_com)){//because each post can have more than one comments
		$com=$row['content'];		
		$user_id_1=$row['user_id'];
		$user = "select *from users where user_id='$user_id_1' AND account_status=1";
		$run_user = mysqli_query($con,$user);
		$row_user = mysqli_fetch_array($run_user);
		$com_name = $row_user['name'];
		$date=$row['comment_date'];
		echo"
		<div class='row'>
			<div class='col-md-6 col-md-offset-3'>
				<div class='panel panel-info'>
					<div class='panel-body'>
					<div>
					<h4><strong>$com_name</strong><i> commented </i>on $date</h4>
					<p class='text-primary' style='margin-left:5px;font-size:20px;'>$com</p>
					</div>
					</div>
				</div>
			</div>
		</div>";
	} 
 ?>