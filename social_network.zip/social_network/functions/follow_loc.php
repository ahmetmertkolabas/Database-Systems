<?php

$con = mysqli_connect("localhost","root","","social_network") or die("Connection was not established");

if(isset($_GET['user_id']) && isset($_GET['loc_id'])) {
	
	$user_id=$_GET['user_id'];
	
	$loc_id =$_GET['loc_id'];

	$insert="insert into loc_sub (user_id,loc_id) values ('$user_id','$loc_id') ";
	$run = mysqli_query($con,$insert);
	if($run){
		echo "<script>alert('fallowing! updated')</script>";
		echo "<script>window.open('home.php')</script>";
	}
	else{
		echo "<script>alert('already fallowing!')</script>";
	}
	
			
} 

?>