<?php

$con = mysqli_connect("localhost","root","","social_network") or die("Connection was not established");

if(isset($_GET['user_id']) && isset($_GET['post_id'])) {
	
	$user_id=$_GET['user_id'];
	
	$post_id =$_GET['post_id'];

	$insert="update likes set type='dislike' where user_id='$user_id' AND post_id='$post_id'";
	$run = mysqli_query($con,$insert);
	if($run){
		echo "<script>alert('fallowing! updated')</script>";
	}
	else{
		echo "<script>alert('already disliked ')</script>";
	}
	
			
} 

?>