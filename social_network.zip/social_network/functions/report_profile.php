<?php

$con = mysqli_connect("localhost","root","","social_network") or die("Connection was not established");

if(isset($_GET['user_id_2']) && isset($_GET['user_id_1'])) {
	
	$user_id_1=$_GET['user_id_1'];
	
	$user_id_2 =$_GET['user_id_2'];

	$insert="insert into user_reports (report_by,reported_id) values ('$user_id_1','$user_id_2') ";
	$run = mysqli_query($con,$insert);
	if($run){
		echo "<script>alert('Reported! updated')</script>";
	}
	else{
		echo "<script>alert('already reported! ')</script>";
	}
	
			
} 

?>