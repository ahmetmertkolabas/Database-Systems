<!DOCTYPE html>
<?php
session_start();
include("includes/admin_header.php");


if(!isset($_SESSION['email'])){
	header("location: index.php");
}
?>
<html>
<head>
	<title>Find People</title>
	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style/home_style2.css">
</head>
<body>
<div class="row">
<?php
	if(isset($_GET['u_id'])){

	$u_id=$_GET['u_id'];
}
if($u_id<0 || $u_id==''){
	
	echo"<script>window.open('admin_panel.php','_self')</script>";
}
else{
?>	
<div class="col-sm-12">
	<?php
		if(isset($_GET['u_id'])){

		global $con;
		$user_id=$_GET['u_id'];
		$select="select * from users where user_id=$user_id";
		$run=mysqli_query($con, $select);
		$row= mysqli_fetch_array($run); 
		$name=$row['username'];
	}
	?>
	<?php
		if(isset($_GET['u_id'])&isset($_GET['a_id'])){
		global $con;
		$user_id=$_GET['u_id'];
		$admin_id=$_GET['a_id'];
		$select="select * from users where user_id=$user_id";
		$run=mysqli_query($con, $select);
		$row= mysqli_fetch_array($run); 
		$id=$row['user_id'];
		$name = $row['name'];
		$user_name = $row['username'];
		$image = $row['pp_path'];
		$user_gender = $row['gender'];
		$user_birthday = $row['date_of_birth'];
		$user_image = $row['pp_path'];
		$describe_user = $row['bio'];

		$get_followings = "select * from following where user1_id='$id'";
		$run_followings = mysqli_query($con, $get_followings);
		$following=array();

		while($row_followings = mysqli_fetch_array($run_followings))
		{
			$user_id_2=$row_followings['user2_id'];
			$get_user = "select * from users where user_id='$user_id_2'"; 
			$run_user = mysqli_query($con,$get_user);
			$row=mysqli_fetch_array($run_user);
			$user_name_follow= $row['username'];
			array_push($following,$user_name_follow);
		}

		$get_follow_loc = "select * from loc_sub where user_id='$id'";
		$run_follow_loc = mysqli_query($con, $get_follow_loc);
		$follow_loc=array();

		while($row_follow_loc = mysqli_fetch_array($run_follow_loc))
		{
			$loc_id=$row_follow_loc['loc_id'];
			$get_loc = "select * from locations where loc_id='$loc_id'"; 
			$run_loc = mysqli_query($con,$get_loc);
			$row=mysqli_fetch_array($run_loc);
			$loc_name_follow= $row['uni_name'];
			array_push($follow_loc,$loc_name_follow);
		}
		echo "
	
		<div class='row'>
			<div class='col-sm-1'>
			</div>
			<center>
				<div  style='background-color: #e6e6e6'class='col-sm-3'><h2>Information about</h2>
					<img  class='img-circle'src='users/$image' width='150' height='150'><br><br>
					<ul class='list-group'>
						<li class='list-group-item' title='Username'><strong>$user_name</strong></li>
						<li class='list-group-item' title='Name'><strong>$name</strong></li>
						<li class='list-group-item' title='User Status'><strong style='color :grey;'>$describe_user</strong></li>
						<li class='list-group-item' title='Birthday'><strong >$user_birthday</strong></li>
						<li class='list-group-item' title='Gender'><strong >$user_gender</strong></li>
					</ul>
					<form action='' method='post'>
					<span class='input-group-addon'><i class='glyphicon glyphicon-calendar'></i></span>
					<input type='date' class='form-control input-md' placeholder='Date' name='time' required='required'>
					<center><button id='signup' class='btn btn-info btn-lg' name='ban_time'>due date</button></center>
					</form>";
					if (isset($_POST['ban_time'])){
						$date=htmlentities(mysqli_real_escape_string($con,$_POST['time']));
					}
					echo "
					<a href='functions/suspend_profile.php?user_id=$id&admin_id=$admin_id&
					time=$date' style='float:right;'>
					<center><button id='signup' class='btn btn-info btn-lg' name='ban'>suspend</button></center>
					</a><br><br><br>		
		" ;
		echo"<p><strong>following:</strong> </p>";
			foreach($following as $value){ 
    			echo $value;    
			?>  <br />
		<?php
			}
		?>
		<?php 
			echo"<p><strong>following loc:</strong> </p>";
			foreach($follow_loc as $value){ 
    			echo $value;    
		?>  <br />
		<?php
			}
		echo"
			</div>
			</center>";
	}
	?>

	<div class="col-sm-8">
		<center><h1><strong><?php echo"$name ";?></strong>Posts</h1></center>
		<?php
			global $con;
			if(isset($_GET['u_id'])){
			$u_id=$_GET['u_id'];
		}
		$get_posts = "select * from posts where user_id=$u_id AND hidden=0 ORDER by 1 DESC LIMIT 5";

		$run_posts = mysqli_query($con, $get_posts);


					while ($row_posts = mysqli_fetch_array($run_posts)){
				
					$post_id = $row_posts['post_id'] ;
					$user_id = $row_posts['user_id'];
					$content = substr($row_posts['text_content'], 0,40);
					$upload_image = "select *from images where post_id='$post_id'";
					$run_image = mysqli_query($con,$upload_image);
					$row_image = mysqli_fetch_array($run_image); 
					$img_content = $row_image['img_content'];
					$image_id = $row_image['image_id'];
					$post_date = $row_posts['post_date'];


					//find loc_id than location
					$post_loc = "select *from post_loc where post_id='$post_id' ";
					$run_loc = mysqli_query($con,$post_loc);
					$row_loc = mysqli_fetch_array($run_loc); 
					$loc_id = $row_loc['loc_id'];
					$post_loc = "select *from locations where loc_id='$loc_id' ";
					$run_loc = mysqli_query($con,$post_loc);
					$row_loc = mysqli_fetch_array($run_loc); 
					$loc = $row_loc['uni_name'];

					$user = "select *from users where user_id='$u_id' AND account_status=1";
					$run_user = mysqli_query($con,$user);
					$row_user = mysqli_fetch_array($run_user);

					$user_name = $row_user['username'];
					$user_image = $row_user['pp_path']; 

					if(strlen($upload_image) >= 1 && strlen($content) >=0){
						echo"
						<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
					<div class='row'>
						<div class='col-sm-2'>
						<p><img src='users/$user_image' class='img-circle' width='100px' height='100px'></p>
						</div>
						<div class='col-sm-6'>
							<h3><a style='text-decoration:none; cursor:pointer;color #3897f0;' href='user_profile.php?u_id=$user_id'>$user_name</a></h3>
							<h4><small style='color:black;'> Posted on: <strong>$post_date</strong></small></h4>
							<h3>Location: <a style='text-decoration:none; cursor:pointer;color #3897f0;' href='loc_profile.php?loc_id=$loc_id'>$loc</a></h3>
						</div>
						<div class='col-sm-4'>
						</div>
					</div>
					<div class='row'>
						<div class='col-sm-12'>
							<img id='posts-img' src='imagepost/$img_content' style='height:350px;'>
						</div>
					</div><br>
				</div>
				<div class='col-sm-3'>
				</div>
			</div><br><br>
						";
					}
					
				}


		?>
		
	
</div>	
</div>		
</div>
<?php }?>
</body>
</html>