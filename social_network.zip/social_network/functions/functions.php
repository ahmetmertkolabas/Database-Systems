<?php

$con = mysqli_connect("localhost","root","","social_network") or die("Connection was not established");

//function for inserting post

function insertPost(){
	if(isset($_POST['sub'])){
		global $con;
		global $user_id;

		$insert="select MAX(p.post_id) AS current_post_id from posts p ";
		$result = mysqli_query($con, $insert);
		$row=mysqli_fetch_array($result);
		$post_id=$row[0]+1;
		$content = htmlentities($_POST['content']);
		$topic = htmlentities($_POST['topic']);
		$location = htmlentities($_POST['location']);

		//find location id from loc table
		$select_loc = "select *from locations where uni_name='$location' ";
		$run_loc = mysqli_query($con,$select_loc);
		$row_loc = mysqli_fetch_array($run_loc); 
		$loc_id = $row_loc['loc_id'];

		$upload_image = $_FILES['upload_image']['name'];
		$image_tmp = $_FILES['upload_image']['tmp_name'];
		$random_number = rand(1, 100);

		if(strlen($content) > 250){
			echo "<script>alert('Please Use 250 or less than 250 words!')</script>";
			echo "<script>window.open('home.php', '_self')</script>";
		}else{
			if(strlen($upload_image) >= 1 && strlen($content) >=1 && strlen($location) >=1){
				move_uploaded_file($image_tmp, "imagepost/$random_number.$upload_image");
		
				$insert = "insert into posts (user_id, text_content,post_date,post_id) values('$user_id', '$content', NOW(),'$post_id')";
				$insert2="insert into images (img_content,post_id) values('$random_number.$upload_image','$post_id')";
				//$insert="insert into images (img_content) values('$upload_image.$random_number')";
				$insert3="insert into post_loc (post_id,loc_id) values('$post_id','$loc_id') ";

				$run = mysqli_query($con, $insert);
				$run2 = mysqli_query($con, $insert2);
				$run3 = mysqli_query($con, $insert3);

				if($run&&$run2&&$run3){
					echo "<script>alert('Your Post updated a moment ago!')</script>";
					echo "<script>window.open('home.php', '_self')</script>";

					
				}
				else
					{echo "<script>alert('Your Post cant upload !')</script>";}

				exit();
			}else{
				if($upload_image==''||$content==''||$location==''){
					echo "<script>alert('Error Occured while uploading! each post must have loc and text message')</script>";
					echo "<script>window.open('home.php', '_self')</script>";
				}else{
					

						exit();
					
				}
			}
		}
	}
}

function get_posts(){
	global $con;
	$per_page = 4;

	if(isset($_GET['page'])){
		$page = $_GET['page'];
	}else{
		$page=1;
	}
		$user_com=$_SESSION['email'];								//to find user id from SESSION
		$get_com="select * from users where email='$user_com'";
		$run_com =mysqli_query($con,$get_com);
		$row_com=mysqli_fetch_array($run_com);
		$user_id_1=$row_com['user_id'];

	$get_followings = "select * from following where user1_id='$user_id_1'";
	$run_followings = mysqli_query($con, $get_followings);
	while($row_followings = mysqli_fetch_array($run_followings))
	{
		$user_id_2=$row_followings['user2_id'];
		$start_from = ($page-1) * $per_page;

	$get_posts = "select * from posts where user_id='$user_id_2' AND hidden=0 ORDER by 1 DESC LIMIT $start_from, $per_page";//takip edilen postları getiriyor

	$run_posts = mysqli_query($con, $get_posts);

	while($row_posts = mysqli_fetch_array($run_posts)) {

		$post_id = $row_posts['post_id'];
		//find loc_id than location
		$post_loc = "select *from post_loc where post_id='$post_id' ";
		$run_loc = mysqli_query($con,$post_loc);
		$row_loc = mysqli_fetch_array($run_loc); 
		$loc_id = $row_loc['loc_id'];

		$post_loc = "select *from locations where loc_id='$loc_id' ";
		$run_loc = mysqli_query($con,$post_loc);
		$row_loc = mysqli_fetch_array($run_loc); 
		$loc = $row_loc['uni_name'];

		$user_id = $row_posts['user_id'];
		$content = substr($row_posts['text_content'], 0,40);
		$upload_image = "select *from images where post_id='$post_id' ";
		$run_image = mysqli_query($con,$upload_image);
		$row_image = mysqli_fetch_array($run_image); 
		$img_content = $row_image['img_content'];
		$image_id = $row_image['image_id'];
		$post_date = $row_posts['post_date'];

		$user = "select *from users where user_id='$user_id' AND account_status=1";
		$run_user = mysqli_query($con,$user);
		$row_user = mysqli_fetch_array($run_user);

		$user_name = $row_user['username'];
		$user_image = $row_user['pp_path'];

		//now displaying posts from database

		if($content=="" && strlen($img_content) >= 1){
			echo"
			<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
					<div class='row'>
						<div class='col-sm-2'>
						<p><img src='users/$user_image' class='img-circle' width='100px' height='100px'></p>
						</div>
						<div class='col-sm-6'>
							<h3><a style='text-decoration:none; cursor:pointer;color #3897f0;' href='user_profile.php?u_id=$user_id'>$user_name</a></h3>
							<h4><small style='color:black;'> Posted on: <strong>$post_date</strong></small></h4>
							<h3>Location: <a style='text-decoration:none; cursor:pointer;color #3897f0;' href='loc_profile.php?loc_id=$loc_id'>$loc</a></h3>
						</div>
						<div class='col-sm-4'>
						</div>
					</div>
					<div class='row'>
						<div class='col-sm-12'>
							<img id='posts-img' src='imagepost/$img_content' style='height:350px;'>
						</div>
					</div><br>
					<a href='single.php?post_id=$post_id' style='float:right;'><button class='btn btn-info'>Comment</button></a>
					<a href='functions/dislike.php?post_id=$post_id&user_id=$user_id_1' style='float:right;'><button class='btn btn-danger'>Dislike</button></a>
					<a href='functions/like.php?post_id=$post_id&user_id=$user_id_1' style='float:right;'><button class='btn btn-success'>like</button></a>
					<a href='functions/report_post.php?user_id=$user_id_1&post_id=$post_id' style='float:right;'><button class='btn '>Report</button></a>
					
				</div>
				<div class='col-sm-3'>
				</div>
			</div><br><br>
			";
		}

		else if(strlen($content) >= 1 && strlen($upload_image) >= 1){
			echo"
			<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
					<div class='row'>
						<div class='col-sm-2'>
						<p><img src='users/$user_image' class='img-circle' width='100px' height='100px'></p>
						</div>
						<div class='col-sm-6'>
							<h3><a style='text-decoration:none; cursor:pointer;color #3897f0;' href='user_profile.php?u_id=$user_id'>$user_name</a></h3>
							<h4><small style='color:black;'>Posted on: <strong>$post_date</strong></small></h4>
							<h3>Location: <a style='text-decoration:none; cursor:pointer;color #3897f0;' href='loc_profile.php?loc_id=$loc_id'>$loc</a></h3>
						</div>
						<div class='col-sm-4'>
						</div>
					</div>
					<div class='row'>
						<div class='col-sm-12'>
							<p>$content</p>
							<img id='posts-img' src='imagepost/$img_content' style='height:350px;'>
						</div>
					</div><br>
					<a href='single.php?post_id=$post_id' style='float:right;'><button class='btn btn-info'>Comment</button></a>
					<a href='functions/dislike.php?post_id=$post_id&user_id=$user_id_1' style='float:right;'><button class='btn btn-danger'>Dislike</button></a>
					<a href='functions/like.php?post_id=$post_id&user_id=$user_id_1' style='float:right;'><button class='btn btn-success'>like</button></a>
					<a href='functions/report_post.php?user_id=$user_id_1&post_id=$post_id' style='float:right;'><button class='btn '>Report</button></a>
					
				</div>
				<div class='col-sm-3'>
				</div>
			</div><br><br>
			";
		}

		else{
			echo"
			<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
					<div class='row'>
						<div class='col-sm-2'>
						<p><img src='users/$user_image' class='img-circle' width='100px' height='100px'></p>
						</div>
						<div class='col-sm-6'>
							<h3><a style='text-decoration:none; cursor:pointer;color #3897f0;' href='user_profile.php?u_id=$user_id'>$user_name</a></h3>
							<h4><small style='color:black;'>Posted on: <strong>$post_date</strong></small></h4>
							<h3>Location: <a style='text-decoration:none; cursor:pointer;color #3897f0;' href='loc_profile.php?loc_id=$loc_id'>$loc</a></h3>
						</div>
						<div class='col-sm-4'>
						</div>
					</div>
					<div class='row'>
						<div class='col-sm-12'>
							<h3><p>$content</p></h3>
						</div>
					</div><br>
					<a href='single.php?post_id=$post_id' style='float:right;'><button class='btn btn-info'>Comment</button></a>
					<a href='functions/dislike.php?post_id=$post_id&user_id=$user_id_1' style='float:right;'><button class='btn btn-danger'>Dislike</button></a>
					<a href='functions/like.php?post_id=$post_id&user_id=$user_id_1' style='float:right;'><button class='btn btn-success'>like</button></a>
					<a href='functions/report_post.php?user_id=$user_id_1&post_id=$post_id' style='float:right;'><button class='btn '>Report</button></a>
					
				</div>
				<div class='col-sm-3'>
				</div>
			</div><br><br>
			";
		}
	}

	}

	

	include("pagination.php");
}
function get_posts_loc(){
	global $con;
		$user_com=$_SESSION['email'];								//to find user id from SESSION
		$get_com="select * from users where email='$user_com'";
		$run_com =mysqli_query($con,$get_com);
		$row_com=mysqli_fetch_array($run_com);
		$user_id_1=$row_com['user_id'];

	$get_followings = "select * from loc_sub where user_id='$user_id_1'";
	$run_followings = mysqli_query($con, $get_followings);
	while($row_followings = mysqli_fetch_array($run_followings))
	{
		$loc_id=$row_followings['loc_id'];
		$get_post_loc="select * from post_loc where loc_id='$loc_id'";
		$run_loc =mysqli_query($con,$get_post_loc);
		while ($row_loc=mysqli_fetch_array($run_loc)) {
					$post_id=$row_loc['post_id'];
					$post_loc = "select *from locations where loc_id='$loc_id' ";
					$run_loc2 = mysqli_query($con,$post_loc);
					$row_loc = mysqli_fetch_array($run_loc2); 
					$loc = $row_loc['uni_name'];
					$upload_image = "select *from images where post_id='$post_id'";
					$run_image = mysqli_query($con,$upload_image);
					$row_image = mysqli_fetch_array($run_image); 
					$img_content = $row_image['img_content'];
					$image_id = $row_image['image_id'];

					
					if(strlen($upload_image) >= 1 ){
						echo"
						<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
					<div class='row'>
						<div class='col-sm-2'>
						</div>
						<div class='col-sm-6'>
							<h3>Location: <a style='text-decoration:none; cursor:pointer;color #3897f0;' href='loc_profile.php?loc_id=$loc_id'>$loc</a></h3>
						</div>
						<div class='col-sm-4'>
						</div>
					</div>
					<div class='row'>
						<div class='col-sm-12'>
							<img id='posts-img' src='imagepost/$img_content' style='height:350px;'>
						</div>
					</div><br>
				</div>
				<div class='col-sm-3'>
				</div>
			</div><br><br>
						";
					}
		}

	}

}
function single_post(){
	if (isset($_GET['post_id'])) {
		global $con;
		$get_id=$_GET['post_id'];
		$get_post="select * from posts where post_id='$get_id' AND hidden=0 ";
		$run_post =mysqli_query($con,$get_post);
		$row=mysqli_fetch_array($run_post);
		$post_id = $row['post_id'];
		$user_id = $row['user_id'];
		$content = substr($row['text_content'], 0,40);
		$upload_image = "select *from images where post_id='$get_id' ";
		$run_image = mysqli_query($con,$upload_image);
		$row_image = mysqli_fetch_array($run_image); 
		$img_content = $row_image['img_content'];
		$image_id = $row_image['image_id'];
		$post_date = $row['post_date'];
		$user = "select *from users where user_id='$user_id' AND account_status=1";
		$run_user = mysqli_query($con,$user);
		$row_user = mysqli_fetch_array($run_user);

		$user_name = $row_user['username'];
		$user_image = $row_user['pp_path'];

		$user_com=$_SESSION['email'];
		$get_com="select * from users where email='$user_com'";
		$run_com =mysqli_query($con,$get_com);
		$row_com=mysqli_fetch_array($run_com);
		$user_com_id=$row_com['user_id'];

		$get_com_name="select * from users where user_id='$user_com_id'";
		$run_com_name =mysqli_query($con,$get_com_name);
		$row_com_name=mysqli_fetch_array($run_com_name);
		$user_com_name=$row_com_name['username'];



		if($content=="" && strlen($img_content) >= 1){
			echo"
			<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
					<div class='row'>
						<div class='col-sm-2'>
						<p><img src='users/$user_image' class='img-circle' width='100px' height='100px'></p>
						</div>
						<div class='col-sm-6'>
							<h3><a style='text-decoration:none; cursor:pointer;color #3897f0;' href='user_profile.php?u_id=$user_id'>$user_name</a></h3>
							<h4><small style='color:black;'>Posted on: <strong>$post_date</strong></small></h4>
						</div>
						<div class='col-sm-4'>
						</div>
					</div>
					<div class='row'>
						<div class='col-sm-12'>
							<img id='posts-img' src='imagepost/$img_content' style='height:350px;'>
						</div>
					</div><br>
					
				</div>
				<div class='col-sm-3'>
				</div>
			</div><br><br>
			";
		}

		else if(strlen($content) >= 1 && strlen($upload_image) >= 1){
			echo"
			<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
					<div class='row'>
						<div class='col-sm-2'>
						<p><img src='users/$user_image' class='img-circle' width='100px' height='100px'></p>
						</div>
						<div class='col-sm-6'>
							<h3><a style='text-decoration:none; cursor:pointer;color #3897f0;' href='user_profile.php?u_id=$user_id'>$user_name</a></h3>
							<h4><small style='color:black;'>Posted on: <strong>$post_date</strong></small></h4>
						</div>
						<div class='col-sm-4'>
						</div>
					</div>
					<div class='row'>
						<div class='col-sm-12'>
							<p>$content</p>
							<img id='posts-img' src='imagepost/$img_content' style='height:350px;'>
						</div>
					</div><br>
									</div>
				<div class='col-sm-3'>
				</div>
			</div><br><br>
			";
		}

		else{
			echo"
			<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
					<div class='row'>
						<div class='col-sm-2'>
						<p><img src='users/$user_image' class='img-circle' width='100px' height='100px'></p>
						</div>
						<div class='col-sm-6'>
							<h3><a style='text-decoration:none; cursor:pointer;color #3897f0;' href='user_profile.php?u_id=$user_id'>$user_name</a></h3>
							<h4><small style='color:black;'>Posted on: <strong>$post_date</strong></small></h4>
						</div>
						<div class='col-sm-4'>
						</div>
					</div>
					<div class='row'>
						<div class='col-sm-12'>
							<h3><p>$content</p></h3>
						</div>
					</div><br>
					
				</div>
				<div class='col-sm-3'>
				</div>
			</div><br><br>
			";	
		}
		include("comments.php");
		echo"
		<div class='row'>
			<div class='col-md-6 col-md-offset-3'>
				<div class='panel panel-info'>
					<div class='panel-body'>
					<form action='' method='post'class='form-inline'> 
					<textarea placeholder='Write your comment here!' class='pb-cmnt-textarea ' name='comment'></textarea>
					<button class='btn btn-info pull-right'name='reply'>Comment</button>
					</form>


					</div>
				</div>


			</div>
		</div>
		";

		if (isset($_POST['reply'])) {
			$comment=htmlentities($_POST['comment']);

			if ($comment=='') {
				echo "<script>alert('Enter your comment!')</script>";
				echo "<script>window.open('single.php?post_id=$post_id', '_self')</script>";
			}else{
				$insert="insert into comments(post_id,user_id,content,comment_date) values('$post_id','$user_com_id','$comment',NOW())";
				$run = mysqli_query($con,$insert);
				echo "<script>alert('your comment! updated')</script>";
				echo "<script>window.open('single.php?post_id=$post_id', '_self')</script>";
			}
		}



	}

}

function get_posts_admin(){

global $con;
 	$get_post_admin="select * from post_reports";
 	$run_post_admin = mysqli_query($con,$get_post_admin);
 	while ($row_report=mysqli_fetch_array($run_post_admin)) {
 	$post_id=$row_report['reported_id'];
 	$get_post="select * from posts where post_id='$post_id'";
	$run_post =mysqli_query($con,$get_post);
	$row=mysqli_fetch_array($run_post);
	$post_id = $row['post_id'];
	$user_id = $row['user_id'];
	$content = substr($row['text_content'], 0,40);
	$upload_image = "select *from images where post_id='$post_id' ";
	$run_image = mysqli_query($con,$upload_image);
	$row_image = mysqli_fetch_array($run_image); 
	$img_content = $row_image['img_content'];
	$image_id = $row_image['image_id'];
	$post_date = $row['post_date'];
	$user = "select *from users where user_id='$user_id'";
	$run_user = mysqli_query($con,$user);
	$row_user = mysqli_fetch_array($run_user);

		$user_name = $row_user['username'];
		$user_image = $row_user['pp_path'];

		echo"
			<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
					<div class='row'>
						<div class='col-sm-2'>
						<p><img src='users/$user_image' class='img-circle' width='100px' height='100px'></p>
						</div>
						<div class='col-sm-6'>
							<h3><a style='text-decoration:none; cursor:pointer;color #3897f0;' href='user_profile.php?u_id=$user_id'>$user_name</a></h3>
							<h4><small style='color:black;'>Posted on: <strong>$post_date</strong></small></h4>
						</div>
						<div class='col-sm-4'>
						</div>
					</div>
					<div class='row'>
						<div class='col-sm-12'>
							<h3><p>$content</p></h3>
						</div>
						<a href='functions/delete_post.php?post_id=$post_id' style='float:right;'><button class='btn btn-danger'>Delete</button></a>
						<a href='functions/hide_post.php?post_id=$post_id' style='float:right;'><button class='btn btn-danger'>Hide</button></a>
					</div><br>
					
				</div>
				<div class='col-sm-3'>

				</div>

			</div><br><br>
			";


 	}
 	
}
function get_user_admin(){

global $con;
 	$get_user_admin="select * from user_reports";
 	$run_user_admin = mysqli_query($con,$get_user_admin);
 	while ($row_report=mysqli_fetch_array($run_user_admin)) {
 	$user_id=$row_report['reported_id'];
 	$get_user="select * from users where user_id='$user_id'";
	$run_user =mysqli_query($con,$get_user);
	$row=mysqli_fetch_array($run_user);
	$user_id = $row['user_id'];
	$user_name = $row['username'];
	$user_image = $row['pp_path'];

		echo"
			<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
					<div class='row'>
						<div class='col-sm-2'>
						<p><img src='users/$user_image' class='img-circle' width='100px' height='100px'></p>
						</div>
						<div class='col-sm-6'>
							<h3><a style='text-decoration:none; cursor:pointer;color #3897f0;' href='user_profile.php?u_id=$user_id'>$user_name</a></h3>
						</div>
						<div class='col-sm-4'>
						</div>
					</div>
				</div>
				<div class='col-sm-3'>

				</div>

			</div><br><br>
			";


 	}
 	
}
function search_user_admin(){

	global $con;
	if (isset($_GET['search_user_btn'])) {
		$search_query=htmlentities($_GET['search_user']);
		$get_user="select * from users where username like '%$search_query%'";
	}
		else{
			$get_user="select * from users";

		}
		$run_user = mysqli_query($con,$get_user);
		while ( $row=mysqli_fetch_array($run_user)) {
			$user_id = $row['user_id'];
			$user_name = $row['username'];
			$name = $row['name'];
			$user_image = $row['pp_path'];
			$admin = $_SESSION['email'];
			$get_admin = "select * from admin where email='$admin'"; 
			$run_admin = mysqli_query($con,$get_admin);
			$row=mysqli_fetch_array($run_admin);	
			$admin_id = $row['admin_id']; 

			echo"
			<div class='row'>
				<div class='col-sm-3'>
				</div>
					<div class='col-sm-6'>
						<div class='row'id='find_people'>
							<div class='col-sm-4'>
								<a href='user_profile.php?u_id=$user_id'>
								<img src='users/$user_image' class='img-circle' width='150px' height='140px' title='$user_name' stylr='float:left; margin:1px'/>
								</a>
							</div><br>
						<div class='col-sm-6'>
							<a style='text-decoration:none; cursor:pointer;color:#3897f0;'href='user_profile_admin.php?u_id=$user_id&a_id=$admin_id'>
							<strong><h2>$user_name</h2><strong>
							</a>
						</div>
						<div class='col-sm-3'>
						</div>
				</div>
			</div>
			<div class='col-sm-4'>
			</div>
			</div><br>
			";
			
		}


}

function search_user(){

	global $con;
	if (isset($_GET['search_user_btn'])) {
		$search_query=htmlentities($_GET['search_user']);
		$get_user="select * from users where username like '%$search_query%'";
	}
		else{
			$get_user="select * from users";

		}
		$run_user = mysqli_query($con,$get_user);
		while ( $row=mysqli_fetch_array($run_user)) {
			$user_id = $row['user_id'];
			$user_name = $row['username'];
			$name = $row['name'];
			$user_image = $row['pp_path'];

			echo"
			<div class='row'>
				<div class='col-sm-3'>
				</div>
					<div class='col-sm-6'>
						<div class='row'id='find_people'>
							<div class='col-sm-4'>
								<a href='user_profile.php?u_id=$user_id'>
								<img src='users/$user_image' class='img-circle' width='150px' height='140px' title='$user_name' stylr='float:left; margin:1px'/>
								</a>
							</div><br>
						<div class='col-sm-6'>
							<a style='text-decoration:none; cursor:pointer;color:#3897f0;'href='user_profile.php?u_id=$user_id'>
							<strong><h2>$user_name</h2><strong>
							</a>
						</div>
						<div class='col-sm-3'>
						</div>
				</div>
			</div>
			<div class='col-sm-4'>
			</div>
			</div><br>
			";
			
		}
}
function results(){
global $con;
	if (isset($_GET['search'])) {
		$search_query=htmlentities($_GET['user_query']);
		$get_loc="select * from locations where uni_name like '%$search_query%'";
	}
		else{
			$get_loc="select * from locations";

		}
		$run_loc = mysqli_query($con,$get_loc);
		while ( $row=mysqli_fetch_array($run_loc)) {
			$loc_id = $row['loc_id'];
			$loc_name = $row['uni_name'];
			echo"
			<div class='row'>
				<div class='col-sm-3'>
				</div>
					<div class='col-sm-6'>
						<div class='row'id='find_people'>
							<div class='col-sm-4'>
							</div><br>
						<div class='col-sm-6'>
							<a style='text-decoration:none; cursor:pointer;color:#3897f0;'href='loc_profile.php?loc_id=$loc_id'>
							<strong><h2>$loc_name</h2><strong>
							</a>
						</div>
						<div class='col-sm-3'>
						</div>
				</div>
			</div>
			<div class='col-sm-4'>
			</div>
			</div><br>
			";
			
		}


}



?>