<?php 

$con = mysqli_connect("localhost","root","","social_network") or die("Connection was not established");

if(isset($_GET['u_id'])) {
	
	$user_id=$_GET['u_id'];
	$delete="delete from users where user_id=$user_id";
	$run = mysqli_query($con,$delete);
	if ($run) {
				echo "<script>alert('Your account deleted!')</script>";
				header("location:index.php");
			}
				else {
					echo "<script>alert('failed ')</script>";
					}			
} 

 ?>