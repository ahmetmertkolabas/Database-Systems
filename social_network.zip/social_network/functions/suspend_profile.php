<?php

$con = mysqli_connect("localhost","root","","social_network") or die("Connection was not established");

if(isset($_GET['user_id']) && isset($_GET['admin_id']) && isset($_GET['time'])) {
	
	$user_id=$_GET['user_id'];
	$date=$_GET['time'];
	$admin_id =$_GET['admin_id'];

	$insert="insert into blocks (admin_id,user_id,time_until) values ('$admin_id','$user_id','$date') ";
	$run = mysqli_query($con,$insert);
	if($run){
		echo "<script>alert('Reported! updated')</script>";
	}
	else{
		echo "<script>alert('already reported! )</script>";
	}			
} 


?>