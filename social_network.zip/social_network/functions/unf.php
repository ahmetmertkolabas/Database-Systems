<?php

$con = mysqli_connect("localhost","root","","social_network") or die("Connection was not established");

if(isset($_GET['user_id_2']) && isset($_GET['user_id_1'])) {
	
	$user_id_1=$_GET['user_id_1'];
	
	$user_id_2 =$_GET['user_id_2'];

	$delete="delete from  following where (user1_id=$user_id_1 AND user2_id=$user_id_2)";
	$run = mysqli_query($con,$delete);
	if($run){
		echo "<script>alert('fallowing! updated')</script>";
		
	}
	else{
		echo "<script>alert(' already not fallowing')</script>";
	}
	
			
} 

?>