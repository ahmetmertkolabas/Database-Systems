<?php

$con = mysqli_connect("localhost","root","","social_network") or die("Connection was not established");

if(isset($_GET['user_id']) && isset($_GET['loc_id'])) {
	
	$user_id=$_GET['user_id'];
	
	$loc_id =$_GET['loc_id'];

	$delete="delete from  loc_sub where (user_id=$user_id AND loc_id=$loc_id)";
	$run = mysqli_query($con,$delete);
	if($run){
		echo "<script>alert('fallowing! updated')</script>";
	
	}
	else{
		echo "<script>alert(' already not fallowing')</script>";
	}
	
			
} 

?>