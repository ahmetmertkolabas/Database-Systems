<!DOCTYPE html>
<?php
session_start();
include("includes/header.php");

if(!isset($_SESSION['email'])){
	header("location: index.php");

}
?>
<html>
<head>

	<title>Edit Account Setting</title>
	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style/home_style2.css">
</head>
<body>
<div class="row">
		<div class="col-sm-2">
		</div>
		<div class="col-sm-8">
			<form action="" method="post" enctype="multipart/form-data">
				<table class="table table-bordered table-hover">
					<tr align="center">
						<td colspan="6" class="active"><h2>Edit Your Profile</h2>
							
						</td>
					</tr>
					<tr>
						<td style="font-weight: bold;">
							Change your Password
						</td>
						<td>
							<input type="password" name="u_pass" id="mypass" required value="<?php echo $user_pass;?>" class="form-control">
						</td>
					</tr>
					<tr>
						<td style="font-weight: bold;">
							Change your Bio
						</td>
						<td>
							<input type="text" name="bio" placeholder="Password" required value="<?php echo $describe_user;?>" class="form-control">
						</td>
					</tr>
					<tr>
						<td style="font-weight: bold;">
							Change your Username
						</td>
						<td>
							<input type="text" name="u_name"  required value="<?php echo $user_name;?>" class="form-control">
						</td>
					</tr>
					<tr align="center">
						<td colspan="6">
							<input class="btn btn-default" type="submit" name="update" style="width: 250px;" value="Update">
						</td>

					</tr>
				</table>
			</form>
		</div>
		<div class="col-sm-2">	
		</div>

</div>
</body>
</html>
<?php 
		global $con;

	if (isset($_POST['update'])) {

		$pass=htmlentities($_POST['u_pass']);
		$bio=htmlentities($_POST['bio']);
		$u_name=htmlentities($_POST['u_name']);
		$user = $_SESSION['email'];
		$update="update users set username='$u_name',bio='$bio',user_password='$pass' where email='$user'";
		$run=mysqli_query($con,$update);
		if ($run) {
				echo "<script>alert('Your information updated a moment ago!')</script>";
				}
				else {
					echo "<script>alert('failed ')</script>";
					}			
	}

?>