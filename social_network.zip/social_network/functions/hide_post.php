<?php

$con = mysqli_connect("localhost","root","","social_network") or die("Connection was not established");

if(isset($_GET['post_id'])) {
	$post_id=$_GET['post_id'];

	$hide_post="update posts  set hidden=1 where post_id=$post_id";
	$run = mysqli_query($con, $hide_post);
	
	if($run ){
			echo "<script>alert('This Post Hidden a moment ago!')</script>";
			}
				
}  
?>

