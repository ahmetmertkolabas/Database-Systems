<!DOCTYPE html>
<?php
session_start();
include("includes/header.php");

if(!isset($_SESSION['email'])){
	header("location: index.php");
}
?>
<html>
<head>
	<title>Find People</title>
	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style/home_style2.css">
</head>
<body>
<div class="row">
<?php
	if(isset($_GET['loc_id'])){

	$loc_id=$_GET['loc_id'];
}
if($loc_id<0 || $loc_id==''){
	
	echo"<script>window.open('home.php','_self')</script>";
}
else{
?>	
<div class="col-sm-12">
	<?php
		if(isset($_GET['loc_id'])){

		global $con;
		$loc_id=$_GET['loc_id'];
		$select="select * from locations where loc_id=$loc_id";
		$run=mysqli_query($con, $select);
		$row= mysqli_fetch_array($run); 
		$location=$row['uni_name'];

		$user = $_SESSION['email'];
			$get_user = "select * from users where email='$user'"; 
			$run_user = mysqli_query($con,$get_user);
			$row=mysqli_fetch_array($run_user);
			$userown_id=$row['user_id'];
	}
	?>
	<?php
		
		echo"

		<div class='row'>
			<div class='col-sm-1'>
			</div>
			<center>
				<div  style='background-color: #e6e6e6'class='col-sm-3'><h2>Information about</h2>
					<ul class='list-group'>
						<li class='list-group-item' title='Location'><strong>$location</strong></li>
						<a href='functions/unf_loc.php?user_id=$userown_id&loc_id=$loc_id' style='float:right;'><button class='btn btn-danger'>UnFollow</button></a>
					<a href='functions/follow_loc.php?user_id=$userown_id&loc_id=$loc_id' style='float:right;'><button class='btn btn-success'>Follow</button></a>
					</ul>
		";
		echo"</div>
			</center>";
	}

	?>
	<div class="col-sm-8">
		<center><h1><strong><?php echo"$location";?></strong>Posts</h1></center>
		<?php

		$get_post_loc = "select * from post_loc where loc_id=$loc_id ";

		$run_post_loc = mysqli_query($con, $get_post_loc);


					while ($row_post_loc = mysqli_fetch_array($run_post_loc)){
				
					$post_id = $row_post_loc['post_id'] ;
					$post_loc = "select *from locations where loc_id='$loc_id' ";
					$run_loc = mysqli_query($con,$post_loc);
					$row_loc = mysqli_fetch_array($run_loc); 
					$loc = $row_loc['uni_name'];
					$upload_image = "select *from images where post_id='$post_id'";
					$run_image = mysqli_query($con,$upload_image);
					$row_image = mysqli_fetch_array($run_image); 
					$img_content = $row_image['img_content'];
					$image_id = $row_image['image_id'];

					

					if(strlen($upload_image) >= 1 ){
						echo"
						<div class='row'>
				<div class='col-sm-3'>
				</div>
				<div id='posts' class='col-sm-6'>
					<div class='row'>
						<div class='col-sm-2'>
						</div>
						<div class='col-sm-6'>
							<h3>Location: <a style='text-decoration:none; cursor:pointer;color #3897f0;' href='loc_profile.php?loc_id=$loc_id'>$loc</a></h3>
						</div>
						<div class='col-sm-4'>
						</div>
					</div>
					<div class='row'>
						<div class='col-sm-12'>
							<img id='posts-img' src='imagepost/$img_content' style='height:350px;'>
						</div>
					</div><br>
				</div>
				<div class='col-sm-3'>
				</div>
			</div><br><br>
						";
					}
					
				}


		?>
		
	
</div>	
</div>		
</div>

</body>
</html>