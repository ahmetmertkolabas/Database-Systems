<!DOCTYPE html>
<?php
session_start();
include("includes/header.php");

if(!isset($_SESSION['email'])){
	header("location: index.php");
}
?>
<html>
<head>
	<?php
		$user = $_SESSION['email'];//to pass across pages
		$get_user = "select * from users where email='$user'"; 
		$run_user = mysqli_query($con,$get_user);
		$row=mysqli_fetch_array($run_user);
		$user_name = $row['username'];
		$user_id_1=$row['user_id'];
		$get_followings = "select * from following where user1_id='$user_id_1'";
		$run_followings = mysqli_query($con, $get_followings);
		$following=array();

		while($row_followings = mysqli_fetch_array($run_followings))
		{
			$user_id_2=$row_followings['user2_id'];
			$get_user = "select * from users where user_id='$user_id_2'"; 
			$run_user = mysqli_query($con,$get_user);
			$row=mysqli_fetch_array($run_user);
			$user_name_follow= $row['username'];
			array_push($following,$user_name_follow);
		}

		$get_follow_loc = "select * from loc_sub where user_id='$user_id_1'";
		$run_follow_loc = mysqli_query($con, $get_follow_loc);
		$follow_loc=array();

		while($row_follow_loc = mysqli_fetch_array($run_follow_loc))
		{
			$loc_id=$row_follow_loc['loc_id'];
			$get_loc = "select * from locations where loc_id='$loc_id'"; 
			$run_loc = mysqli_query($con,$get_loc);
			$row=mysqli_fetch_array($run_loc);
			$loc_name_follow= $row['uni_name'];
			array_push($follow_loc,$loc_name_follow);
		}
	?>
	<title><?php echo "$user_name"; ?></title>
	<meta charset="utf-8">
 	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style/home_style2.css">
</head>
<style>

	}#profile-img{
		position: relative;
		top: 160px;
		left: 40px;
	}
	#update_profile{
		position: relative;
		top: -33px;
		cursor: pointer;
		left: 93px;
		border-radius: 4px;
		background-color: rgba(0,0,0,0.1);
		transform: translate(-50%, -50%);
	}
	#button_profile{
		position: relative;
		top: 82%;
		left: 93px;
		cursor: pointer;
		transform: translate(-50%, -50%);
	}
	#own_posts{
		border: 5px solid #e6e6e6;
		padding:40px 50px;
	}
	#posts-img{
		height: 300px;
		width: 100px;
	}
</style>
<body>
<div class="row">
	<div class="col-sm-2">	
	</div>
	<div class="col-sm-8">
		<?php
			echo"
			
			<div id='profile-img'>
				<img src='users/$user_image' alt='Profile' class='img-circle' width='180px' height='185px'>
				<form action='profile.php?u_id='$user_id' method='post' enctype='multipart/form-data'>
				<label id='update_profile'> Select Profile
				<input type='file' name='u_image' size='60' />
				</label><br><br>
				<button id='button_profile' name='update' class='btn btn-info'>Update Profile</button>
				</form>
			</div><br>
			";
		?>
	</div>


	<?php
		if(isset($_POST['update'])){

				$u_image = $_FILES['u_image']['name'];
				$image_tmp = $_FILES['u_image']['tmp_name'];
				$random_number = rand(1,100);

				if($u_image==''){
					echo "<script>alert('Please Select Profile Image on clicking on your profile image')</script>";
					echo "<script>window.open('profile.php?u_id=$user_id' , '_self')</script>";
					exit();
				}else{
					move_uploaded_file($image_tmp, "users/$u_image.$random_number");
					$update = "update users set pp_path='$u_image.$random_number' where user_id='$user_id'";

					$run = mysqli_query($con, $update);

					if($run){
					echo "<script>alert('Your Profile Updated')</script>";
					echo "<script>window.open('profile.php?u_id=$user_id' , '_self')</script>";
					}
				}

			}
	?>
	<div class="col-sm-2">
	</div>
</div>

<div class="row">
	<div class="col-sm-2">
	</div>
	<div class="col-sm-2" style="background-color: #e6e6e6;text-align: center;left: 0.8%;border-radius: 5px;">
		<?php
		echo"
			<center><h2><strong>About</strong></h2></center>
			<center><h4><strong>$name</strong></h4></center>
			<p><strong><i style='color:grey;'>$describe_user</i></strong></p><br>
			<p><strong>Gender: </strong> $user_gender</p><br>
			<p><strong>Date of Birth: </strong> $user_birthday</p><br>
		<a href='edit_profile.php?u_id=$user_id 'class='btn btn-success'/>Edit Profile</a><br><br><br>
		";
		?>
		<?php 
			echo"<p><strong>following:</strong> </p>";
			foreach($following as $value){ 
    			echo $value;    
			?>  <br />
		<?php
			}
		?>
		<?php 
			echo"<p><strong>following loc:</strong> </p>";
			foreach($follow_loc as $value){ 
    			echo $value;    
		?>  <br />
		<?php
			}
		?>
	</div>
	
	<div class="col-sm-6">
		<?php 
			global $con;

			if(isset($_GET['u_id'])){
				$u_id = $_GET['u_id'];
			}
			$get_posts = "select * from posts where user_id=$u_id AND hidden=0 ORDER by 1 DESC LIMIT 5";

			$run_posts = mysqli_query($con, $get_posts);

			while ($row_posts = mysqli_fetch_array($run_posts)){
				
					$post_id = $row_posts['post_id'] ;

					//find loc_id than location
					$post_loc = "select *from post_loc where post_id='$post_id' ";
					$run_loc = mysqli_query($con,$post_loc);
					$row_loc = mysqli_fetch_array($run_loc); 
					$loc_id = $row_loc['loc_id'];

					$post_loc = "select *from locations where loc_id='$loc_id' ";
					$run_loc = mysqli_query($con,$post_loc);
					$row_loc = mysqli_fetch_array($run_loc); 
					$loc = $row_loc['uni_name'];

					$user_id = $row_posts['user_id'];
					$content = substr($row_posts['text_content'], 0,40);
					$upload_image = "select *from images where post_id='$post_id'";
					$run_image = mysqli_query($con,$upload_image);
					$row_image = mysqli_fetch_array($run_image); 
					$img_content = $row_image['img_content'];
					$image_id = $row_image['image_id'];
					$post_date = $row_posts['post_date'];

					$user = "select *from users where user_id='$u_id' AND account_status=1";
					$run_user = mysqli_query($con,$user);
					$row_user = mysqli_fetch_array($run_user);

					$user_name = $row_user['username'];
					$user_image = $row_user['pp_path']; 

					if(strlen($upload_image) >= 1 && strlen($content) >=0){
						echo"
						<div id='own_posts'>
								<div class='row'>
							<div class='col-sm-2'>
							<p><img src='users/$user_image' class='img-circle' width='100px' height='100px'></p>
							</div>
							<div class='col-sm-6'>
								<h3><a style='text-decoration:none; cursor:pointer;color #3897f0;' href='profile.php?u_id=$user_id'>$user_name</a></h3>
								<h4><small style='color:black;'>Updated a post on <strong>$post_date</strong></small></h4>
								<h3>Location: <a style='text-decoration:none; cursor:pointer;color #3897f0;' href='loc_profile.php?loc_id=$loc_id'>$loc</a></h3>
								</div>
								<div class='col-sm-4'>
								</div>
							</div>
							<div class='row'>
							<div class='col-sm-12'>
								<img id='posts-img' src='imagepost/$img_content' style='height:350px;'>
								<h3><p>$content</p></h3>
							</div>
						</div><br>
						<a href='single.php?post_id=$post_id' style='float:right;'><button class='btn btn-success'>View</button></a>
						<a href='edit_post.php?post_id=$post_id' style='float:right;'><button class='btn btn-info'>Edit</button></a>
						<a href='functions/delete_post.php?post_id=$post_id' style='float:right;'><button class='btn btn-danger'>Delete</button></a>
						</div><br><br>
						";
					}
					include("functions/delete_post.php");
				}
		 ?>
		
	</div>
	<div class="col-sm-2">
		
	</div>
</div>

</body>
</html>