<?php
include("includes/connection.php");
include("functions/functions.php");

?>
<nav class="navbar navbar-default">
	<div class="container-fluid">
		<div class="navbar-header">
			<button type="button" class="navbar-toggle collapsed" data-target="#bs-example-navbar-collapse-1" data-toggle="collapse" aria-expanded="false">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			</button>
			<a href='logout.php'>Logout</a>
		</div>

		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	      <ul class="nav navbar-nav">
	      	
	      	<?php 
			$admin = $_SESSION['email'];
			$get_admin = "select * from admin where email='$admin'"; 
			$run_admin = mysqli_query($con,$get_admin);
			$row=mysqli_fetch_array($run_admin);
					
			$admin_id = $row['admin_id']; 
			$name = $row['admin_name'];
			?>

	       	<li><a href="admin_panel.php">Panel</a></li>
			<li><a href="members2.php">Find People</a></li>

			</ul>
			
		</div>
	</div>
</nav>